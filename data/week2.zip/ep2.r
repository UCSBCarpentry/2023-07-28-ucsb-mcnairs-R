# Project Management
# Setting up your workspace really helps

# Demo the week 1 script

# ALL: Download week 2 files
# 10 minutes


getwd()

# be careful where you make these
dir.create("doc")
dir.create("data")
dir.create("src")

# All: 
# 2 minutes
# Download 3 datafiles to your laptop
# Upload them to you Rstudio week2 data folder
### Red / Green ###

download.file("https://datacarpentry.org/r-intro-geospatial/data/nordic-data.csv",
              "data/nordic-data.csv")
download.file("https://datacarpentry.org/r-intro-geospatial/data/nordic-data-2.csv",
              "data/nordic-data-2.csv")
download.file("https://datacarpentry.org/r-intro-geospatial/data/gapminder_data.csv",
              "data/gapminder_data.csv")

