# episode 5
# Subsetting vectors and dataframes

# a simple numeric vector with names
x <- c(5.4, 6.2, 7.1, 4.8, 7.5)
names(x) <- c('a', 'b', 'c', 'd', 'e')
x

# command for how many values?
# command for ranges and averages?
# what's the difference between mean and median?

# we can call individual elements any number of ways:
x[1]
x[4]
x[c(1,3)]

# or a range:
x[2:4]

# or repeats:
x[c(1,1,2,2,4,4)]

# or all elements EXCEPT:
x[-2]


# challenge ####################
# given this code:

x <- c(5.4, 6.2, 7.1, 4.8, 7.5)
names(x) <- c('a', 'b', 'c', 'd', 'e')
print(x)

# write 3 different ways to  get this output:
#   b   c   d 
#   6.2 7.1 4.8 







# and we can use the names to get the values out:
x["a"]
x[c("a", "c")]




# back to gapminder
# give me the 3rd column
head(gapminder[3])
head(gapminder[3:5])

# and these are 2 dimensional, so we can call rows and columns
# [x,y]

gapminder[1:3,]
gapminder[3, ]
gapminder[,3]

# challenge ########################
#
# Fix these mistakes
#
# Extract observations collected for the year 1957
gapminder[gapminder$year = 1957, ]

# Extract all columns except 1 through to 4
gapminder[, -1:4]

# Extract the rows where the life expectancy is longer the 80 years
gapminder[gapminder$lifeExp > 80]

# Extract the first row, and the fourth and fifth columns (lifeExp and gdpPercap).
gapminder[1, 4, 5]



# final grand challenge
#
# What country had the lowest life expectancy in
# in 1987?

