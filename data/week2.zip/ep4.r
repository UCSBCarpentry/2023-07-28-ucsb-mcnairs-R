# ep. 4
# Exploring Dataframes
#    diving into a realistic example

getwd()
gapminder <- read.csv("data/gapminder_data.csv",
                      stringsAsFactors = TRUE)

# if we didn't have it, we could download it using code:
download.file("https://datacarpentry.org/r-intro-geospatial/data/gapminder_data.csv",
              destfile = "data/gapminder_data.csv")

# or all in one line:
gapminder <- read.csv("https://datacarpentry.org/r-intro-geospatial/data/gapminder_data.csv", 
                      stringsAsFactors = TRUE) 


str(gapminder)
class(gapminder$year)
class(gapminder$country)
str(gapminder$country)
length(gapminder)
ncol(gapminder)
nrow(gapminder)
dim(gapminder)
colnames(gapminder)
head(gapminder)


# what would be the last few rows?

# ????????????????????


# adding columns
# first make a test:
below_average <- gapminder$lifeExp < 70.5
head(below_average)

# then we add the results as a column:
cbind(gapminder, below_average)
head(gapminder)
str(gapminder)

# but that didn't save results.
gapminder <- cbind(gapminder, below_average)
str(gapminder)


# rbind() works like cbind()
# but:
#     rows are lists because they are mixed datatypes
#     you need to watch out for your factors:
new_row <- list('Norway', 2016, 5000000, 'Nordic', 80.3, 49400.0, FALSE)
gapminder_norway <- rbind(gapminder, new_row)

# Norway breaks the rules of the factor.
# You need to explicitly add a new valid value
# to factors
tail(gapminder_norway)


# one bonus: summary
summary(gapminder)

# challenge:
# make a new one row dataframe with your own info
# 
#    -first name
#    -last name
#    -favorite ice cream
# then use rbind to add in your partner's name and fav flav
# below is the generic form for making a dataframe:
df <- data.frame(id = c("a", "b", "c"),
                 x = 1:3,
                 y = c(TRUE, TRUE, FALSE),
                 stringsAsFactors = FALSE)

