# ep 3
# exploring tables

nordic <- read.csv("data/nordic-data.csv")

str(nordic)
nordic$country

# can operate on a whole column at once
nordic$lifeExp + 2

# why doesn't this work?
nordic$lifeExp + nordic$country

# this does:
nordic$lifeExp + nordic$year




# that's because of datatypes
# sometimes in excel that would bite you 

# you can always ask R
class(3.14)
class(pi)
class(1)
class(1L)

# ^^^ that's pretty esoteric



# All:
# load nordic-data-2.csv
# and name the dataframe nordic_2
# we just got new data on life expectancy





# a little lesson about
# type coercion

my_vector <- vector(length = 3)
# default type is boolean. default value is false
my_vector

# if I want a new, empty vector of a specific type, 
# I need to tell R what kind:
another_vector <- vector(mode = 'character', length = 3)
another_vector
# brackets indicate that it's a vector of a certain size
str(another_vector)

str(nordic$lifeExp)


# the c() function
# "combine" elements into a vector.
# let R figure out the type
combine_vector <- c(2, 6, 3)
combine_vector
str(combine_vector)


# pop quiz 1 ####################
# RED    = num
# GREEN  = chr
# WITHOUT running it, what type of
# vector will this produce?

quiz_vector <- c(2, 6, '3')



# pop quiz 2 ####################
# RED    = num
# GREEN  = bool
another_coercion_vector <- c(0, TRUE)
another_coercion_vector
str(another_coercion_vector)



# pop quiz 3 #####################
# Given what you now know about type conversion, 
# look at the class of data in nordic_2$lifeExp 
# and compare it with nordic$lifeExp. 
# Why are these columns different classes?


str(nordic_2$lifeExp)
str(nordic$lifeExp)


# little tricks for c()

# you can stack them
# so some argue c() stands for concatenate
ab <- c("a", "b")
ab 
ab <- c(ab, "CD")
ab

a_series <- 1:10
a_series
b_series <- seq(10)
b_series
-b_series

c_series <- seq(1,10, by= 0.1)
c_series

# other ways of exploring a vector or dataframe
head(c_series)
head()


# and different ways to call out pieces of dataframes
str(nordic)

# first column
nordic[1]
nordic[[1]]
nordic$country
nordic["country"]

# first column, first row
nordic[1, 1]


nordic[, 1]

#how about first row all the columns?
# red/green


